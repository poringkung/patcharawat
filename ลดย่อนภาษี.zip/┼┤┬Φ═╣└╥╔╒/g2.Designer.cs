﻿namespace ลดย่อนภาษี
{
    partial class g2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ลดย่อน = new System.Windows.Forms.TextBox();
            this.รายได้สุทธิ = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.คำนวน = new System.Windows.Forms.Button();
            this.salary12 = new System.Windows.Forms.TextBox();
            this.taxtopay = new System.Windows.Forms.TextBox();
            this.จำนวนภาษีที่ต้องจ่าย = new System.Windows.Forms.Label();
            this.ย้อนกลับ = new System.Windows.Forms.Button();
            this.re = new System.Windows.Forms.Button();
            this.label102 = new System.Windows.Forms.Label();
            this.รวมค่าประกันเงินออม = new System.Windows.Forms.TextBox();
            this.ประกันสังคม = new System.Windows.Forms.NumericUpDown();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.rmf = new System.Windows.Forms.NumericUpDown();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.ltf = new System.Windows.Forms.NumericUpDown();
            this.label50 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.บำนาญ = new System.Windows.Forms.NumericUpDown();
            this.กบข = new System.Windows.Forms.NumericUpDown();
            this.ทุนสำรอง = new System.Windows.Forms.NumericUpDown();
            this.กอช = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.ประกันสมรส = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.เบี้ยสุขภาพ_บด = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.เบี้ยสุขภาพ = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.เบี้ยชีวิต = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ประกันสังคม)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rmf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ltf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.บำนาญ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.กบข)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ทุนสำรอง)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.กอช)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ประกันสมรส)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยสุขภาพ_บด)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยสุขภาพ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยชีวิต)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.groupBox1);
            this.groupBox6.Controls.Add(this.ย้อนกลับ);
            this.groupBox6.Controls.Add(this.re);
            this.groupBox6.Controls.Add(this.label102);
            this.groupBox6.Controls.Add(this.รวมค่าประกันเงินออม);
            this.groupBox6.Controls.Add(this.ประกันสังคม);
            this.groupBox6.Controls.Add(this.label59);
            this.groupBox6.Controls.Add(this.label60);
            this.groupBox6.Controls.Add(this.rmf);
            this.groupBox6.Controls.Add(this.label57);
            this.groupBox6.Controls.Add(this.label58);
            this.groupBox6.Controls.Add(this.ltf);
            this.groupBox6.Controls.Add(this.label50);
            this.groupBox6.Controls.Add(this.label43);
            this.groupBox6.Controls.Add(this.label49);
            this.groupBox6.Controls.Add(this.label48);
            this.groupBox6.Controls.Add(this.label42);
            this.groupBox6.Controls.Add(this.label47);
            this.groupBox6.Controls.Add(this.label46);
            this.groupBox6.Controls.Add(this.label45);
            this.groupBox6.Controls.Add(this.label44);
            this.groupBox6.Controls.Add(this.บำนาญ);
            this.groupBox6.Controls.Add(this.กบข);
            this.groupBox6.Controls.Add(this.ทุนสำรอง);
            this.groupBox6.Controls.Add(this.กอช);
            this.groupBox6.Controls.Add(this.label41);
            this.groupBox6.Controls.Add(this.label40);
            this.groupBox6.Controls.Add(this.label39);
            this.groupBox6.Controls.Add(this.label38);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Controls.Add(this.ประกันสมรส);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.เบี้ยสุขภาพ_บด);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.เบี้ยสุขภาพ);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.เบี้ยชีวิต);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Font = new System.Drawing.Font("Quark", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(3, 14);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1262, 671);
            this.groupBox6.TabIndex = 171;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "ค่าลดหย่อนกลุ่มประกันเงินออม และการลงทุน ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ลดย่อน);
            this.groupBox1.Controls.Add(this.รายได้สุทธิ);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.คำนวน);
            this.groupBox1.Controls.Add(this.salary12);
            this.groupBox1.Controls.Add(this.taxtopay);
            this.groupBox1.Controls.Add(this.จำนวนภาษีที่ต้องจ่าย);
            this.groupBox1.Location = new System.Drawing.Point(1012, 50);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(238, 528);
            this.groupBox1.TabIndex = 240;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "คำนวนและสรุปผล";
            // 
            // ลดย่อน
            // 
            this.ลดย่อน.BackColor = System.Drawing.Color.White;
            this.ลดย่อน.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ลดย่อน.Location = new System.Drawing.Point(128, 45);
            this.ลดย่อน.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ลดย่อน.Name = "ลดย่อน";
            this.ลดย่อน.Size = new System.Drawing.Size(107, 39);
            this.ลดย่อน.TabIndex = 25;
            this.ลดย่อน.Text = "0";
            this.ลดย่อน.TextChanged += new System.EventHandler(this.ลดย่อน_TextChanged);
            // 
            // รายได้สุทธิ
            // 
            this.รายได้สุทธิ.AutoSize = true;
            this.รายได้สุทธิ.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.รายได้สุทธิ.Location = new System.Drawing.Point(18, 49);
            this.รายได้สุทธิ.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.รายได้สุทธิ.Name = "รายได้สุทธิ";
            this.รายได้สุทธิ.Size = new System.Drawing.Size(96, 33);
            this.รายได้สุทธิ.TabIndex = 22;
            this.รายได้สุทธิ.Text = "รายได้สุทธิ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 144);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 33);
            this.label3.TabIndex = 5;
            this.label3.Text = "เงินเดือนต่อปี";
            // 
            // คำนวน
            // 
            this.คำนวน.BackColor = System.Drawing.Color.Yellow;
            this.คำนวน.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.คำนวน.Location = new System.Drawing.Point(82, 375);
            this.คำนวน.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.คำนวน.Name = "คำนวน";
            this.คำนวน.Size = new System.Drawing.Size(92, 51);
            this.คำนวน.TabIndex = 14;
            this.คำนวน.Text = "คำนวน";
            this.คำนวน.UseVisualStyleBackColor = false;
            // 
            // salary12
            // 
            this.salary12.BackColor = System.Drawing.Color.White;
            this.salary12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.salary12.Location = new System.Drawing.Point(128, 148);
            this.salary12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.salary12.Name = "salary12";
            this.salary12.Size = new System.Drawing.Size(107, 32);
            this.salary12.TabIndex = 4;
            this.salary12.Text = "0";
            // 
            // taxtopay
            // 
            this.taxtopay.BackColor = System.Drawing.Color.White;
            this.taxtopay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.taxtopay.Location = new System.Drawing.Point(68, 280);
            this.taxtopay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.taxtopay.Name = "taxtopay";
            this.taxtopay.Size = new System.Drawing.Size(107, 29);
            this.taxtopay.TabIndex = 6;
            this.taxtopay.Text = "0";
            // 
            // จำนวนภาษีที่ต้องจ่าย
            // 
            this.จำนวนภาษีที่ต้องจ่าย.AutoSize = true;
            this.จำนวนภาษีที่ต้องจ่าย.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.จำนวนภาษีที่ต้องจ่าย.ForeColor = System.Drawing.Color.Red;
            this.จำนวนภาษีที่ต้องจ่าย.Location = new System.Drawing.Point(40, 239);
            this.จำนวนภาษีที่ต้องจ่าย.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.จำนวนภาษีที่ต้องจ่าย.Name = "จำนวนภาษีที่ต้องจ่าย";
            this.จำนวนภาษีที่ต้องจ่าย.Size = new System.Drawing.Size(158, 24);
            this.จำนวนภาษีที่ต้องจ่าย.TabIndex = 7;
            this.จำนวนภาษีที่ต้องจ่าย.Text = "จำนวนภาษีที่ต้องจ่าย";
            // 
            // ย้อนกลับ
            // 
            this.ย้อนกลับ.Font = new System.Drawing.Font("Quark", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ย้อนกลับ.Location = new System.Drawing.Point(39, 617);
            this.ย้อนกลับ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ย้อนกลับ.Name = "ย้อนกลับ";
            this.ย้อนกลับ.Size = new System.Drawing.Size(121, 35);
            this.ย้อนกลับ.TabIndex = 239;
            this.ย้อนกลับ.Text = "<-- ย้อนกลับ";
            this.ย้อนกลับ.UseVisualStyleBackColor = true;
            // 
            // re
            // 
            this.re.Font = new System.Drawing.Font("Quark", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.re.Location = new System.Drawing.Point(1109, 617);
            this.re.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.re.Name = "re";
            this.re.Size = new System.Drawing.Size(107, 35);
            this.re.TabIndex = 238;
            this.re.Text = "รีเซ็ตค่า";
            this.re.UseVisualStyleBackColor = true;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.BackColor = System.Drawing.SystemColors.Control;
            this.label102.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(486, 505);
            this.label102.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(246, 33);
            this.label102.TabIndex = 237;
            this.label102.Text = "รวมค่าลดหย่อนประกันเงินออม";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // รวมค่าประกันเงินออม
            // 
            this.รวมค่าประกันเงินออม.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.รวมค่าประกันเงินออม.ForeColor = System.Drawing.Color.Black;
            this.รวมค่าประกันเงินออม.Location = new System.Drawing.Point(753, 505);
            this.รวมค่าประกันเงินออม.Name = "รวมค่าประกันเงินออม";
            this.รวมค่าประกันเงินออม.ReadOnly = true;
            this.รวมค่าประกันเงินออม.Size = new System.Drawing.Size(129, 39);
            this.รวมค่าประกันเงินออม.TabIndex = 236;
            this.รวมค่าประกันเงินออม.Text = "0";
            this.รวมค่าประกันเงินออม.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ประกันสังคม
            // 
            this.ประกันสังคม.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ประกันสังคม.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ประกันสังคม.Location = new System.Drawing.Point(286, 50);
            this.ประกันสังคม.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ประกันสังคม.Maximum = new decimal(new int[] {
            9000,
            0,
            0,
            0});
            this.ประกันสังคม.Name = "ประกันสังคม";
            this.ประกันสังคม.Size = new System.Drawing.Size(111, 39);
            this.ประกันสังคม.TabIndex = 187;
            this.ประกันสังคม.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label59.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.Red;
            this.label59.Location = new System.Drawing.Point(910, 436);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(18, 23);
            this.label59.TabIndex = 229;
            this.label59.Text = "0";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label60.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label60.Location = new System.Drawing.Point(749, 436);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(241, 46);
            this.label60.TabIndex = 228;
            this.label60.Text = "ไม่เกิน 15% ของเงินได้ จำนวน               บาท\r\nและไม่เกิน 500,000 บาท";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rmf
            // 
            this.rmf.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rmf.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rmf.Location = new System.Drawing.Point(753, 396);
            this.rmf.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rmf.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.rmf.Name = "rmf";
            this.rmf.Size = new System.Drawing.Size(120, 39);
            this.rmf.TabIndex = 227;
            this.rmf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label57.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.Red;
            this.label57.Location = new System.Drawing.Point(910, 318);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(18, 23);
            this.label57.TabIndex = 226;
            this.label57.Text = "0";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label58.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label58.Location = new System.Drawing.Point(757, 318);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(241, 46);
            this.label58.TabIndex = 225;
            this.label58.Text = "ไม่เกิน 15% ของเงินได้ จำนวน               บาท\r\nและไม่เกิน 500,000 บาท";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ltf
            // 
            this.ltf.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ltf.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltf.Location = new System.Drawing.Point(753, 279);
            this.ltf.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ltf.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.ltf.Name = "ltf";
            this.ltf.Size = new System.Drawing.Size(120, 39);
            this.ltf.TabIndex = 224;
            this.ltf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label50.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.Red;
            this.label50.Location = new System.Drawing.Point(910, 227);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(18, 23);
            this.label50.TabIndex = 217;
            this.label50.Text = "0";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.SystemColors.Control;
            this.label43.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(512, 400);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(179, 33);
            this.label43.TabIndex = 206;
            this.label43.Text = "จำนวนที่จะลงทุน RMF";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label49.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Red;
            this.label49.Location = new System.Drawing.Point(910, 94);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(18, 23);
            this.label49.TabIndex = 216;
            this.label49.Text = "0";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label48.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.Red;
            this.label48.Location = new System.Drawing.Point(456, 552);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(18, 23);
            this.label48.TabIndex = 215;
            this.label48.Text = "0";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label48.Click += new System.EventHandler(this.label48_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.SystemColors.Control;
            this.label42.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(520, 279);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(172, 33);
            this.label42.TabIndex = 205;
            this.label42.Text = "จำนวนที่จะลงทุน LTF";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label47.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label47.Location = new System.Drawing.Point(749, 227);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(241, 46);
            this.label47.TabIndex = 214;
            this.label47.Text = "ไม่เกิน 15% ของเงินได้ จำนวน               บาท\r\nและไม่เกิน 200,000 บาท";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label46.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label46.Location = new System.Drawing.Point(299, 461);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(109, 23);
            this.label46.TabIndex = 213;
            this.label46.Text = "ไม่เกิน 13,200 บาท";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label46.Click += new System.EventHandler(this.label46_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label45.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label45.Location = new System.Drawing.Point(749, 94);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(241, 46);
            this.label45.TabIndex = 212;
            this.label45.Text = "ไม่เกิน 15% ของเงินได้ จำนวน               บาท\r\nและไม่เกิน 500,000 บาท ";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label44.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label44.Location = new System.Drawing.Point(280, 552);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(251, 46);
            this.label44.TabIndex = 211;
            this.label44.Text = "ไม่เกิน 15% ของรายได้ จำนวน                 บาท\r\nและไม่เกิน 490,000 บาท";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // บำนาญ
            // 
            this.บำนาญ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.บำนาญ.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.บำนาญ.Location = new System.Drawing.Point(753, 188);
            this.บำนาญ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.บำนาญ.Maximum = new decimal(new int[] {
            200000,
            0,
            0,
            0});
            this.บำนาญ.Name = "บำนาญ";
            this.บำนาญ.Size = new System.Drawing.Size(120, 39);
            this.บำนาญ.TabIndex = 210;
            this.บำนาญ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // กบข
            // 
            this.กบข.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.กบข.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.กบข.Location = new System.Drawing.Point(753, 56);
            this.กบข.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.กบข.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.กบข.Name = "กบข";
            this.กบข.Size = new System.Drawing.Size(120, 39);
            this.กบข.TabIndex = 209;
            this.กบข.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ทุนสำรอง
            // 
            this.ทุนสำรอง.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ทุนสำรอง.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ทุนสำรอง.Location = new System.Drawing.Point(284, 504);
            this.ทุนสำรอง.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ทุนสำรอง.Maximum = new decimal(new int[] {
            490000,
            0,
            0,
            0});
            this.ทุนสำรอง.Name = "ทุนสำรอง";
            this.ทุนสำรอง.Size = new System.Drawing.Size(112, 39);
            this.ทุนสำรอง.TabIndex = 208;
            this.ทุนสำรอง.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // กอช
            // 
            this.กอช.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.กอช.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.กอช.Location = new System.Drawing.Point(285, 421);
            this.กอช.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.กอช.Maximum = new decimal(new int[] {
            13200,
            0,
            0,
            0});
            this.กอช.Name = "กอช";
            this.กอช.Size = new System.Drawing.Size(112, 39);
            this.กอช.TabIndex = 207;
            this.กอช.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.SystemColors.Control;
            this.label41.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(499, 188);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(216, 33);
            this.label41.TabIndex = 204;
            this.label41.Text = "เบี้ยประกันชีวิตแบบบำนาญ";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.Control;
            this.label40.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(52, 425);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(127, 33);
            this.label40.TabIndex = 203;
            this.label40.Text = "เงินสะสม กอช.";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.SystemColors.Control;
            this.label39.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(476, 56);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(241, 66);
            this.label39.TabIndex = 202;
            this.label39.Text = "เงินสะสมกองทุน กบข.\r\nและกองทุนสงเคราะห์ครูเอกชน";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.Control;
            this.label38.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(34, 517);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(209, 33);
            this.label38.TabIndex = 201;
            this.label38.Text = "เงินกองทุนสำรองเลี้ยงชีพ";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label34.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label34.Location = new System.Drawing.Point(298, 388);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(110, 23);
            this.label34.TabIndex = 200;
            this.label34.Text = "ไม่เกิน 10,000 บาท";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ประกันสมรส
            // 
            this.ประกันสมรส.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ประกันสมรส.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ประกันสมรส.Location = new System.Drawing.Point(284, 349);
            this.ประกันสมรส.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ประกันสมรส.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ประกันสมรส.Name = "ประกันสมรส";
            this.ประกันสมรส.Size = new System.Drawing.Size(112, 39);
            this.ประกันสมรส.TabIndex = 199;
            this.ประกันสมรส.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.SystemColors.Control;
            this.label33.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(50, 365);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(154, 33);
            this.label33.TabIndex = 198;
            this.label33.Text = "ประกันชีวิตคู่สมรส";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label32.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label32.Location = new System.Drawing.Point(298, 318);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(109, 23);
            this.label32.TabIndex = 197;
            this.label32.Text = "ไม่เกิน 15,000 บาท";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // เบี้ยสุขภาพ_บด
            // 
            this.เบี้ยสุขภาพ_บด.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.เบี้ยสุขภาพ_บด.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เบี้ยสุขภาพ_บด.Location = new System.Drawing.Point(286, 278);
            this.เบี้ยสุขภาพ_บด.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เบี้ยสุขภาพ_บด.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.เบี้ยสุขภาพ_บด.Name = "เบี้ยสุขภาพ_บด";
            this.เบี้ยสุขภาพ_บด.Size = new System.Drawing.Size(112, 39);
            this.เบี้ยสุขภาพ_บด.TabIndex = 196;
            this.เบี้ยสุขภาพ_บด.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.Control;
            this.label31.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(50, 262);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(150, 66);
            this.label31.TabIndex = 195;
            this.label31.Text = "เบี้ยประกันสุขภาพ\r\n(บิดา - มารดา)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label30.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label30.Location = new System.Drawing.Point(300, 238);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(109, 23);
            this.label30.TabIndex = 194;
            this.label30.Text = "ไม่เกิน 15,000 บาท";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label29.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label29.Location = new System.Drawing.Point(291, 161);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(118, 23);
            this.label29.TabIndex = 193;
            this.label29.Text = "ไม่เกิน 100,000 บาท";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label28.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label28.Location = new System.Drawing.Point(303, 90);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(105, 23);
            this.label28.TabIndex = 192;
            this.label28.Text = "ไม่เกิน 9,000 บาท";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // เบี้ยสุขภาพ
            // 
            this.เบี้ยสุขภาพ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.เบี้ยสุขภาพ.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เบี้ยสุขภาพ.Location = new System.Drawing.Point(285, 198);
            this.เบี้ยสุขภาพ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เบี้ยสุขภาพ.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.เบี้ยสุขภาพ.Name = "เบี้ยสุขภาพ";
            this.เบี้ยสุขภาพ.Size = new System.Drawing.Size(111, 39);
            this.เบี้ยสุขภาพ.TabIndex = 191;
            this.เบี้ยสุขภาพ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.Control;
            this.label26.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(50, 198);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(150, 33);
            this.label26.TabIndex = 190;
            this.label26.Text = "เบี้ยประกันสุขภาพ";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // เบี้ยชีวิต
            // 
            this.เบี้ยชีวิต.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.เบี้ยชีวิต.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เบี้ยชีวิต.Location = new System.Drawing.Point(285, 121);
            this.เบี้ยชีวิต.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เบี้ยชีวิต.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.เบี้ยชีวิต.Name = "เบี้ยชีวิต";
            this.เบี้ยชีวิต.Size = new System.Drawing.Size(111, 39);
            this.เบี้ยชีวิต.TabIndex = 189;
            this.เบี้ยชีวิต.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.Control;
            this.label25.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(52, 122);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(124, 33);
            this.label25.TabIndex = 188;
            this.label25.Text = "เบี้ยประกันชีวิต";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.Control;
            this.label24.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(53, 56);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(112, 33);
            this.label24.TabIndex = 186;
            this.label24.Text = "ประกันสังคม";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // g2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox6);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "g2";
            this.Size = new System.Drawing.Size(1276, 688);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ประกันสังคม)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rmf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ltf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.บำนาญ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.กบข)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ทุนสำรอง)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.กอช)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ประกันสมรส)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยสุขภาพ_บด)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยสุขภาพ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยชีวิต)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.TextBox รวมค่าประกันเงินออม;
        private System.Windows.Forms.NumericUpDown ประกันสังคม;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.NumericUpDown rmf;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.NumericUpDown ltf;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown บำนาญ;
        private System.Windows.Forms.NumericUpDown กบข;
        private System.Windows.Forms.NumericUpDown ทุนสำรอง;
        private System.Windows.Forms.NumericUpDown กอช;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown ประกันสมรส;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.NumericUpDown เบี้ยสุขภาพ_บด;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown เบี้ยสุขภาพ;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown เบี้ยชีวิต;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button คำนวน;
        private System.Windows.Forms.TextBox salary12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ลดย่อน;
        private System.Windows.Forms.Label จำนวนภาษีที่ต้องจ่าย;
        private System.Windows.Forms.Label รายได้สุทธิ;
        private System.Windows.Forms.TextBox taxtopay;
        private System.Windows.Forms.Button ย้อนกลับ;
        private System.Windows.Forms.Button re;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}
