﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ลดย่อนภาษี
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            panel1.Visible = false;
            คู่สมรส.Text = "โสด";
        }      
        private void คู่สมรส_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(คู่สมรส.Text == "โสด")
            {
                ฝากครรภ์.Enabled = false;
                บุตร60.Enabled = false;
                บุตร61.Enabled = false;
                บิดามารดาคู่สมรส.Enabled = false;                
            }
            else if(คู่สมรส.Text == "คู่สมรส มีรายได้")
            {
                ฝากครรภ์.Enabled = true;
                บุตร60.Enabled = true;
                บุตร61.Enabled = true;
                บิดามารดาคู่สมรส.Enabled = true;
            }
            else if (คู่สมรส.Text == "คู่สมรส ไม่มีรายได้")
            {
                ฝากครรภ์.Enabled = true;
                บุตร60.Enabled = true;
                บุตร61.Enabled = true;
                บิดามารดาคู่สมรส.Enabled = true;
            }
            else
            {
                ฝากครรภ์.Enabled = true;
                บุตร60.Enabled = true;
                บุตร61.Enabled = true;
                บิดามารดาคู่สมรส.Enabled = false;
            }
        }

        private void ถัดไป_Click(object sender, EventArgs e)
        {
            ประกันสังคม_ValueChanged(sender, e);
            numericUpDown2_ValueChanged(sender, e);
            panel1.Visible = true;
        }
        private double sl,g1,gg2,sum2,sum3,sum1234,sum333,sum4;
     
        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            g1 = 0;
            sl = Convert.ToInt32(numericUpDown2.Value) * 12;
            int antenatal = Convert.ToInt32(ฝากครรภ์.Value);
            int disabled = Convert.ToInt32(พิการ.Value) * 60000;
            int c60 = Convert.ToInt32(บุตร60.Value) * 30000;
            int c61 = Convert.ToInt32(บุตร61.Value);
            int pd = Convert.ToInt32(บิดามารดาเรา.Value) * 30000;
            int pd2 = Convert.ToInt32(บิดามารดาคู่สมรส.Value) * 30000;
            double temp = sl * 0.5;
            if (c61 >= 1)
            {
                if (c60 == 0)
                {
                    c61 = (c61 * 60000) - 30000;
                }
                else
                {
                    c61 = c61 * 60000;
                }
            }
            else
            {
                c61 = 0;
            }
            if (คู่สมรส.Text == "คู่สมรส ไม่มีรายได้")
            {
                g1 = antenatal + disabled + c60 + c61 + pd + pd2 + 120000;
            }
            else
            {
                g1 = antenatal + disabled + c60 + c61 + pd + pd2 + 60000;
            }
            if (temp > 100000)
            { g1 += 100000; }
            else
            { g1 += temp; }
            textBox1.Text = g1.ToString();
            sum1234 = sl - g1 - sum2 - sum3 - gg2 - sum333;
            if (sum1234 < 0)
            { sum1234 = 0; }
            ลดย่อน.Text = sum1234.ToString();
        }

        private void เงินบริจาคทั้วไป_ValueChanged(object sender, EventArgs e)
        {
            double g = Convert.ToInt32(เงินบริจาคทั้วไป.Value);
            double g2 = Convert.ToInt32(เงินบริจาคอื่นๆ.Value) * 2;
            sum4 = (sl-(g1 + gg2 + sum2 + sum3)) * 0.1;
            label27.Text = sum4.ToString();
            if ((g + g2) > sum4)
            {
                sum333 = sum4;
            }
            else
            {
                sum333 = g + g2;
            }
            รวมเงินบริจาค.Text = sum333.ToString();
        }

        private void ช่วยชาติ_ValueChanged(object sender, EventArgs e)
        {
            int b1 = Convert.ToInt32(ช่วยชาติ.Value);
            int b2 = Convert.ToInt32(หนังสือ.Value);
            int b3 = Convert.ToInt32(เที่ยวเมืองรอง.Value);
            int b4 = Convert.ToInt32(เที่ยวเมืองหลัก.Value);
            int b5 = Convert.ToInt32(ซื้อการศึกษา.Value);
            int b6 = Convert.ToInt32(โอทอป.Value);
            int sum;
            if (b3 + b4 <= 20000)
            {
                sum = b3 + b4;
            }
            else
            {
                sum = 20000;
            }
            sum2 = sum + b1 + b2 + b5 + b6;
            textBox2.Text = sum2.ToString();
        }

        private void ดอกเบี้ยบ้าน_ValueChanged(object sender, EventArgs e)
        {
            int interest = Convert.ToInt32(ดอกเบี้ยบ้าน.Value);
            int home = Convert.ToInt32(บ้านหลังแรก.Value);
            double home2 = Convert.ToInt32(บ้านหลังแรก62.Value) * 0.04;
            double sum;
            if (home <= 3000000)
            {
                sum = home * 0.04;
            }
            else
            {
                sum = home * 0;
            }
            gg2 = sum + home2 + interest;
            รวมค่าอสังหาริมทรพย์.Text = gg2.ToString();
            label17.Text = sum.ToString();
            label20.Text = home2.ToString();
        }

        private void ประกันสังคม_ValueChanged(object sender, EventArgs e)
        {
            int p = Convert.ToInt32(ประกันสังคม.Value);
            int p2 = Convert.ToInt32(เบี้ยชีวิต.Value);
            int p3 = Convert.ToInt32(เบี้ยสุขภาพ.Value);
            int p4 = Convert.ToInt32(เบี้ยสุขภาพ_บด.Value);
            int p5 = Convert.ToInt32(ประกันสมรส.Value);
            int p6 = Convert.ToInt32(กอช.Value);
            int p7 = Convert.ToInt32(ทุนสำรอง.Value);
            int p8 = Convert.ToInt32(กบข.Value);
            int p9 = Convert.ToInt32(บำนาญ.Value);
            int p10 = Convert.ToInt32(ltf.Value);
            int p11 = Convert.ToInt32(rmf.Value);
            int sump2p3,sump9p7p8p11;
            double sl2 = sl * 0.15;
            if (p2 + p3 >= 100000)
            {
                sump2p3 = 100000;
            }
            else
            {
                sump2p3 = p2 + p3;
            }
            if(p7+p8+p9+p11>=500000)
            {
                sump9p7p8p11 = 500000;
            }
            else
            {
                sump9p7p8p11 = p7 + p8 + p9 + p11;
            }
            if (sl2 > 500000)
            {
                ทุนสำรอง.Maximum = 500000;
                label48.Text = sl2.ToString();
            }
            else
            {
                ทุนสำรอง.Maximum = Convert.ToInt32(sl2);
                label48.Text = sl2.ToString();
            }
            if (sl2 > 500000)
            {
                กบข.Maximum = 500000;
                label49.Text = sl2.ToString();
            }
            else
            {
                กบข.Maximum = Convert.ToInt32(sl2);
                label49.Text = sl2.ToString();
            }
            if (sl2 > 200000)
            {
                บำนาญ.Maximum = 200000;
                label50.Text = sl2.ToString();
            }
            else
            {
                บำนาญ.Maximum = Convert.ToInt32(sl2);
                label50.Text = sl2.ToString();
            }
            if (sl2 > 500000)
            {
                ltf.Maximum = 500000;
                label57.Text = sl2.ToString();
            }
            else
            {
                ltf.Maximum = Convert.ToInt32(sl2);
                label57.Text = sl2.ToString();
            }
            if (sl2 > 500000)
            {
                rmf.Maximum = 500000;
                label59.Text = sl2.ToString();
            }
            else
            {
                rmf.Maximum = Convert.ToInt32(sl2);
                label59.Text = sl2.ToString();
            }
            sum3 = p + sump2p3  + p4+ p5 + p6 + sump9p7p8p11 + p10 ;
            รวมค่าประกันเงินออม.Text = sum3.ToString();
        }

        private void re_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            คู่สมรส.Text = "โสด";
            numericUpDown2.Value = 0;
            ฝากครรภ์.Value = 0;
            พิการ.Value = 0;
            บุตร60.Value = 0;
            บุตร61.Value = 0;
            บิดามารดาเรา.Value = 0;
            บิดามารดาคู่สมรส.Value = 0;
            ดอกเบี้ยบ้าน.Value = 0;
            บ้านหลังแรก.Value = 0;
            บ้านหลังแรก62.Value = 0;
            ช่วยชาติ.Value = 0;
            ซื้อการศึกษา.Value = 0;
            หนังสือ.Value = 0;
            โอทอป.Value = 0;
            เที่ยวเมืองหลัก.Value = 0;
            เที่ยวเมืองรอง.Value = 0;
            เงินบริจาคทั้วไป.Value = 0;
            เงินบริจาคอื่นๆ.Value = 0;
            ประกันสังคม.Value = 0;
            เบี้ยชีวิต.Value = 0;
            เบี้ยสุขภาพ.Value = 0;
            เบี้ยสุขภาพ_บด.Value = 0;
            ประกันสมรส.Value = 0;
            ทุนสำรอง.Value = 0;
            กบข.Value = 0;
            บำนาญ.Value = 0;
            ltf.Value = 0;
            rmf.Value = 0;
            ลดย่อน.Text = "0";
            salary12.Text = "0";
            taxtopay.Text = "0";
            textBox1.Text = "0";
            textBox2.Text = "0";
            รวมค่าอสังหาริมทรพย์.Text = "0";
            รวมเงินบริจาค.Text = "0";
            รวมค่าประกันเงินออม.Text = "0";
        }

        private void ย้อนกลับ_Click(object sender, EventArgs e)
        {
            numericUpDown2_ValueChanged(sender, e);
            panel1.Visible = false;
        }

        private void คำนวน_Click(object sender, EventArgs e)
        {
            numericUpDown2_ValueChanged(sender, e);
            if (sum1234>=0&&sum1234<=150000)
            {
                sum1234 = 0;
            }
            else if (sum1234 > 150000 && sum1234 <= 300000)
            {
                sum1234 = (sum1234 - 150000) * 0.05;
            }
            else if (sum1234 > 300000 && sum1234 <= 500000)
            {
                sum1234 = ((sum1234 - 300000)*0.1) + 7500;
            }
            else if (sum1234 > 500000 && sum1234 <= 750000)
            {
                sum1234 = ((sum1234 - 500000) * 0.15) + 27500;
            }
            else if (sum1234 > 750000 && sum1234 <= 1000000)
            {
                sum1234 = ((sum1234 - 750000) * 0.2) + 65000;
            }
            else if (sum1234 > 1000000 && sum1234 <= 2000000)
            {
                sum1234 = ((sum1234 - 1000000) * 0.25) + 115000;
            }
            else if (sum1234 > 2000000 && sum1234 <= 5000000)
            {
                sum1234 = ((sum1234 - 2000000) * 0.3) + 365000;
            }
            else if (sum1234 > 5000000)
            {
                sum1234 = ((sum1234 - 5000000) * 0.35) + 1265000;
            }
            taxtopay.Text = sum1234.ToString();
            salary12.Text = sl.ToString();
        }
    }
}
