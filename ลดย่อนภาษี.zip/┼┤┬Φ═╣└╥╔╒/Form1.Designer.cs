﻿namespace ลดย่อนภาษี
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ฝากครรภ์ = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.พิการ = new System.Windows.Forms.NumericUpDown();
            this.บิดามารดาคู่สมรส = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.บิดามารดาเรา = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.บุตร61 = new System.Windows.Forms.NumericUpDown();
            this.บุตร60 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.คู่สมรส = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.รวมค่าอสังหาริมทรพย์ = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.บ้านหลังแรก62 = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.บ้านหลังแรก = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.ดอกเบี้ยบ้าน = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ลดย่อน = new System.Windows.Forms.TextBox();
            this.รายได้สุทธิ = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.คำนวน = new System.Windows.Forms.Button();
            this.salary12 = new System.Windows.Forms.TextBox();
            this.taxtopay = new System.Windows.Forms.TextBox();
            this.จำนวนภาษีที่ต้องจ่าย = new System.Windows.Forms.Label();
            this.ย้อนกลับ = new System.Windows.Forms.Button();
            this.re = new System.Windows.Forms.Button();
            this.label102 = new System.Windows.Forms.Label();
            this.รวมค่าประกันเงินออม = new System.Windows.Forms.TextBox();
            this.ประกันสังคม = new System.Windows.Forms.NumericUpDown();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.rmf = new System.Windows.Forms.NumericUpDown();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.ltf = new System.Windows.Forms.NumericUpDown();
            this.label50 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.บำนาญ = new System.Windows.Forms.NumericUpDown();
            this.กบข = new System.Windows.Forms.NumericUpDown();
            this.ทุนสำรอง = new System.Windows.Forms.NumericUpDown();
            this.กอช = new System.Windows.Forms.NumericUpDown();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.ประกันสมรส = new System.Windows.Forms.NumericUpDown();
            this.label56 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.เบี้ยสุขภาพ_บด = new System.Windows.Forms.NumericUpDown();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.เบี้ยสุขภาพ = new System.Windows.Forms.NumericUpDown();
            this.label66 = new System.Windows.Forms.Label();
            this.เบี้ยชีวิต = new System.Windows.Forms.NumericUpDown();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.ถัดไป = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.รวมเงินบริจาค = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.เงินบริจาคอื่นๆ = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.เงินบริจาคทั้วไป = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.เที่ยวเมืองรอง = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.เที่ยวเมืองหลัก = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.โอทอป = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.หนังสือ = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.ซื้อการศึกษา = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.ช่วยชาติ = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.ฝากครรภ์)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.พิการ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.บิดามารดาคู่สมรส)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.บิดามารดาเรา)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.บุตร61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.บุตร60)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.บ้านหลังแรก62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.บ้านหลังแรก)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ดอกเบี้ยบ้าน)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ประกันสังคม)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rmf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ltf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.บำนาญ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.กบข)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ทุนสำรอง)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.กอช)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ประกันสมรส)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยสุขภาพ_บด)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยสุขภาพ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยชีวิต)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.เงินบริจาคอื่นๆ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.เงินบริจาคทั้วไป)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.เที่ยวเมืองรอง)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.เที่ยวเมืองหลัก)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.โอทอป)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.หนังสือ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ซื้อการศึกษา)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ช่วยชาติ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("RSU", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(160, 111);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 40);
            this.label1.TabIndex = 1;
            this.label1.Text = "เงินเดือน";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 35);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 24);
            this.label4.TabIndex = 11;
            this.label4.Text = "ค่าฝากครรภ์และ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 59);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 24);
            this.label5.TabIndex = 12;
            this.label5.Text = "ค่าคลอดบุตร";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 97);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 24);
            this.label6.TabIndex = 16;
            this.label6.Text = "ค่าอุปการะคนพิการ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(339, 32);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 24);
            this.label7.TabIndex = 19;
            this.label7.Text = "มีบุตรก่อนปี พ.ศ.2561";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(339, 76);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(136, 24);
            this.label8.TabIndex = 20;
            this.label8.Text = "มีบุตรหลังปี พ.ศ.2561";
            // 
            // ฝากครรภ์
            // 
            this.ฝากครรภ์.BackColor = System.Drawing.Color.White;
            this.ฝากครรภ์.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ฝากครรภ์.Location = new System.Drawing.Point(150, 35);
            this.ฝากครรภ์.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ฝากครรภ์.Maximum = new decimal(new int[] {
            60000,
            0,
            0,
            0});
            this.ฝากครรภ์.Name = "ฝากครรภ์";
            this.ฝากครรภ์.Size = new System.Drawing.Size(90, 31);
            this.ฝากครรภ์.TabIndex = 21;
            this.ฝากครรภ์.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.พิการ);
            this.groupBox2.Controls.Add(this.บิดามารดาคู่สมรส);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.บิดามารดาเรา);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.บุตร61);
            this.groupBox2.Controls.Add(this.บุตร60);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.คู่สมรส);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.ฝากครรภ์);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Font = new System.Drawing.Font("RSU", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupBox2.Location = new System.Drawing.Point(24, 153);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(606, 219);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ค่าลดหย่อนครอบครัว";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("RSU", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label2.Location = new System.Drawing.Point(40, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 29);
            this.label2.TabIndex = 35;
            this.label2.Text = "รวม";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(150, 181);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(91, 31);
            this.textBox1.TabIndex = 34;
            this.textBox1.Text = "0";
            // 
            // พิการ
            // 
            this.พิการ.BackColor = System.Drawing.Color.White;
            this.พิการ.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.พิการ.Location = new System.Drawing.Point(150, 95);
            this.พิการ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.พิการ.Maximum = new decimal(new int[] {
            60000,
            0,
            0,
            0});
            this.พิการ.Name = "พิการ";
            this.พิการ.Size = new System.Drawing.Size(90, 31);
            this.พิการ.TabIndex = 33;
            this.พิการ.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // บิดามารดาคู่สมรส
            // 
            this.บิดามารดาคู่สมรส.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.บิดามารดาคู่สมรส.Location = new System.Drawing.Point(481, 163);
            this.บิดามารดาคู่สมรส.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.บิดามารดาคู่สมรส.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.บิดามารดาคู่สมรส.Name = "บิดามารดาคู่สมรส";
            this.บิดามารดาคู่สมรส.Size = new System.Drawing.Size(90, 31);
            this.บิดามารดาคู่สมรส.TabIndex = 29;
            this.บิดามารดาคู่สมรส.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label11.Location = new System.Drawing.Point(297, 167);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(184, 24);
            this.label11.TabIndex = 28;
            this.label11.Text = "บิดา มารดา คู่สมรสอายุเกิน60";
            // 
            // บิดามารดาเรา
            // 
            this.บิดามารดาเรา.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.บิดามารดาเรา.Location = new System.Drawing.Point(481, 123);
            this.บิดามารดาเรา.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.บิดามารดาเรา.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.บิดามารดาเรา.Name = "บิดามารดาเรา";
            this.บิดามารดาเรา.Size = new System.Drawing.Size(90, 31);
            this.บิดามารดาเรา.TabIndex = 27;
            this.บิดามารดาเรา.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label10.Location = new System.Drawing.Point(334, 124);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 24);
            this.label10.TabIndex = 26;
            this.label10.Text = "บิดา มารดา อายุเกิน60";
            // 
            // บุตร61
            // 
            this.บุตร61.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.บุตร61.Location = new System.Drawing.Point(481, 76);
            this.บุตร61.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.บุตร61.Name = "บุตร61";
            this.บุตร61.Size = new System.Drawing.Size(90, 31);
            this.บุตร61.TabIndex = 25;
            this.บุตร61.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // บุตร60
            // 
            this.บุตร60.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.บุตร60.Location = new System.Drawing.Point(481, 30);
            this.บุตร60.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.บุตร60.Name = "บุตร60";
            this.บุตร60.Size = new System.Drawing.Size(90, 31);
            this.บุตร60.TabIndex = 24;
            this.บุตร60.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("RSU", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label9.Location = new System.Drawing.Point(28, 144);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 29);
            this.label9.TabIndex = 23;
            this.label9.Text = "คู่สมรส";
            // 
            // คู่สมรส
            // 
            this.คู่สมรส.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.คู่สมรส.FormattingEnabled = true;
            this.คู่สมรส.Items.AddRange(new object[] {
            "โสด",
            "คู่สมรส มีรายได้",
            "คู่สมรส ไม่มีรายได้",
            "หย่า"});
            this.คู่สมรส.Location = new System.Drawing.Point(150, 141);
            this.คู่สมรส.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.คู่สมรส.Name = "คู่สมรส";
            this.คู่สมรส.Size = new System.Drawing.Size(91, 32);
            this.คู่สมรส.TabIndex = 22;
            this.คู่สมรส.SelectedIndexChanged += new System.EventHandler(this.คู่สมรส_SelectedIndexChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.รวมค่าอสังหาริมทรพย์);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.บ้านหลังแรก62);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.บ้านหลังแรก);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.ดอกเบี้ยบ้าน);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Location = new System.Drawing.Point(24, 378);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox4.Size = new System.Drawing.Size(606, 204);
            this.groupBox4.TabIndex = 28;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "ค่าลดหย่อนอสังหาริมทรัพย์";
            // 
            // รวมค่าอสังหาริมทรพย์
            // 
            this.รวมค่าอสังหาริมทรพย์.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.รวมค่าอสังหาริมทรพย์.Location = new System.Drawing.Point(458, 88);
            this.รวมค่าอสังหาริมทรพย์.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.รวมค่าอสังหาริมทรพย์.Name = "รวมค่าอสังหาริมทรพย์";
            this.รวมค่าอสังหาริมทรพย์.Size = new System.Drawing.Size(91, 31);
            this.รวมค่าอสังหาริมทรพย์.TabIndex = 38;
            this.รวมค่าอสังหาริมทรพย์.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(262, 88);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(187, 24);
            this.label21.TabIndex = 37;
            this.label21.Text = "รวมค่าลดหย่อนอสังหาริมทรพย์";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(535, 60);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(14, 18);
            this.label20.TabIndex = 36;
            this.label20.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(382, 60);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(224, 18);
            this.label19.TabIndex = 35;
            this.label19.Text = "ลดหย่อนได้ 4% ของค่าบ้านจำนวน                 บาท ";
            // 
            // บ้านหลังแรก62
            // 
            this.บ้านหลังแรก62.BackColor = System.Drawing.Color.White;
            this.บ้านหลังแรก62.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.บ้านหลังแรก62.Location = new System.Drawing.Point(458, 28);
            this.บ้านหลังแรก62.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.บ้านหลังแรก62.Maximum = new decimal(new int[] {
            5000000,
            0,
            0,
            0});
            this.บ้านหลังแรก62.Name = "บ้านหลังแรก62";
            this.บ้านหลังแรก62.Size = new System.Drawing.Size(90, 31);
            this.บ้านหลังแรก62.TabIndex = 34;
            this.บ้านหลังแรก62.ValueChanged += new System.EventHandler(this.ดอกเบี้ยบ้าน_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(262, 33);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(187, 24);
            this.label18.TabIndex = 33;
            this.label18.Text = "ซื้อบ้านหลังแรกในปี พ.ศ. 2562 ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(264, 173);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 18);
            this.label17.TabIndex = 32;
            this.label17.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(154, 119);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(207, 72);
            this.label16.TabIndex = 25;
            this.label16.Text = "หากบ้านหรือคอนโดหลังแรกของคุณราคาไม่เกิน \r\n3,000,000 บาท คุณสามารถนำ 20% ของค่า\r\n" +
    "บ้านมาลดหย่อนภาษีได้ 5 ปี (ได้ปีละ 4%)\r\n(2558  - 2562 ) จำนวน                  บ" +
    "าท";
            // 
            // บ้านหลังแรก
            // 
            this.บ้านหลังแรก.BackColor = System.Drawing.Color.White;
            this.บ้านหลังแรก.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.บ้านหลังแรก.Location = new System.Drawing.Point(157, 83);
            this.บ้านหลังแรก.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.บ้านหลังแรก.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.บ้านหลังแรก.Name = "บ้านหลังแรก";
            this.บ้านหลังแรก.Size = new System.Drawing.Size(90, 31);
            this.บ้านหลังแรก.TabIndex = 24;
            this.บ้านหลังแรก.ValueChanged += new System.EventHandler(this.ดอกเบี้ยบ้าน_ValueChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(14, 83);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(128, 24);
            this.label15.TabIndex = 23;
            this.label15.Text = "โครงการบ้านหลังแรก";
            // 
            // ดอกเบี้ยบ้าน
            // 
            this.ดอกเบี้ยบ้าน.BackColor = System.Drawing.Color.White;
            this.ดอกเบี้ยบ้าน.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ดอกเบี้ยบ้าน.Location = new System.Drawing.Point(157, 28);
            this.ดอกเบี้ยบ้าน.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ดอกเบี้ยบ้าน.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ดอกเบี้ยบ้าน.Name = "ดอกเบี้ยบ้าน";
            this.ดอกเบี้ยบ้าน.Size = new System.Drawing.Size(90, 31);
            this.ดอกเบี้ยบ้าน.TabIndex = 22;
            this.ดอกเบี้ยบ้าน.ValueChanged += new System.EventHandler(this.ดอกเบี้ยบ้าน_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(40, 33);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 24);
            this.label14.TabIndex = 12;
            this.label14.Text = "ดอกเบี้ยบ้าน";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1275, 650);
            this.panel1.TabIndex = 37;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.groupBox5);
            this.groupBox6.Controls.Add(this.ย้อนกลับ);
            this.groupBox6.Controls.Add(this.re);
            this.groupBox6.Controls.Add(this.label102);
            this.groupBox6.Controls.Add(this.รวมค่าประกันเงินออม);
            this.groupBox6.Controls.Add(this.ประกันสังคม);
            this.groupBox6.Controls.Add(this.label59);
            this.groupBox6.Controls.Add(this.label60);
            this.groupBox6.Controls.Add(this.rmf);
            this.groupBox6.Controls.Add(this.label57);
            this.groupBox6.Controls.Add(this.label58);
            this.groupBox6.Controls.Add(this.ltf);
            this.groupBox6.Controls.Add(this.label50);
            this.groupBox6.Controls.Add(this.label43);
            this.groupBox6.Controls.Add(this.label49);
            this.groupBox6.Controls.Add(this.label48);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label47);
            this.groupBox6.Controls.Add(this.label46);
            this.groupBox6.Controls.Add(this.label45);
            this.groupBox6.Controls.Add(this.label44);
            this.groupBox6.Controls.Add(this.บำนาญ);
            this.groupBox6.Controls.Add(this.กบข);
            this.groupBox6.Controls.Add(this.ทุนสำรอง);
            this.groupBox6.Controls.Add(this.กอช);
            this.groupBox6.Controls.Add(this.label51);
            this.groupBox6.Controls.Add(this.label52);
            this.groupBox6.Controls.Add(this.label53);
            this.groupBox6.Controls.Add(this.label54);
            this.groupBox6.Controls.Add(this.label55);
            this.groupBox6.Controls.Add(this.ประกันสมรส);
            this.groupBox6.Controls.Add(this.label56);
            this.groupBox6.Controls.Add(this.label61);
            this.groupBox6.Controls.Add(this.เบี้ยสุขภาพ_บด);
            this.groupBox6.Controls.Add(this.label62);
            this.groupBox6.Controls.Add(this.label63);
            this.groupBox6.Controls.Add(this.label64);
            this.groupBox6.Controls.Add(this.label65);
            this.groupBox6.Controls.Add(this.เบี้ยสุขภาพ);
            this.groupBox6.Controls.Add(this.label66);
            this.groupBox6.Controls.Add(this.เบี้ยชีวิต);
            this.groupBox6.Controls.Add(this.label67);
            this.groupBox6.Controls.Add(this.label68);
            this.groupBox6.Font = new System.Drawing.Font("Quark", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(2, 12);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1262, 631);
            this.groupBox6.TabIndex = 172;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "ค่าลดหย่อนกลุ่มประกันเงินออม และการลงทุน ";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ลดย่อน);
            this.groupBox5.Controls.Add(this.รายได้สุทธิ);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.คำนวน);
            this.groupBox5.Controls.Add(this.salary12);
            this.groupBox5.Controls.Add(this.taxtopay);
            this.groupBox5.Controls.Add(this.จำนวนภาษีที่ต้องจ่าย);
            this.groupBox5.Location = new System.Drawing.Point(1012, 50);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox5.Size = new System.Drawing.Size(238, 528);
            this.groupBox5.TabIndex = 240;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "คำนวนและสรุปผล";
            // 
            // ลดย่อน
            // 
            this.ลดย่อน.BackColor = System.Drawing.Color.White;
            this.ลดย่อน.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ลดย่อน.Location = new System.Drawing.Point(128, 45);
            this.ลดย่อน.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ลดย่อน.Name = "ลดย่อน";
            this.ลดย่อน.Size = new System.Drawing.Size(107, 39);
            this.ลดย่อน.TabIndex = 25;
            this.ลดย่อน.Text = "0";
            // 
            // รายได้สุทธิ
            // 
            this.รายได้สุทธิ.AutoSize = true;
            this.รายได้สุทธิ.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.รายได้สุทธิ.Location = new System.Drawing.Point(18, 49);
            this.รายได้สุทธิ.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.รายได้สุทธิ.Name = "รายได้สุทธิ";
            this.รายได้สุทธิ.Size = new System.Drawing.Size(96, 33);
            this.รายได้สุทธิ.TabIndex = 22;
            this.รายได้สุทธิ.Text = "รายได้สุทธิ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 144);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 33);
            this.label12.TabIndex = 5;
            this.label12.Text = "เงินเดือนต่อปี";
            // 
            // คำนวน
            // 
            this.คำนวน.BackColor = System.Drawing.Color.Yellow;
            this.คำนวน.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.คำนวน.Location = new System.Drawing.Point(82, 375);
            this.คำนวน.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.คำนวน.Name = "คำนวน";
            this.คำนวน.Size = new System.Drawing.Size(92, 51);
            this.คำนวน.TabIndex = 14;
            this.คำนวน.Text = "คำนวน";
            this.คำนวน.UseVisualStyleBackColor = false;
            this.คำนวน.Click += new System.EventHandler(this.คำนวน_Click);
            // 
            // salary12
            // 
            this.salary12.BackColor = System.Drawing.Color.White;
            this.salary12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.salary12.Location = new System.Drawing.Point(128, 148);
            this.salary12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.salary12.Name = "salary12";
            this.salary12.Size = new System.Drawing.Size(107, 32);
            this.salary12.TabIndex = 4;
            this.salary12.Text = "0";
            // 
            // taxtopay
            // 
            this.taxtopay.BackColor = System.Drawing.Color.White;
            this.taxtopay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.taxtopay.Location = new System.Drawing.Point(68, 280);
            this.taxtopay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.taxtopay.Name = "taxtopay";
            this.taxtopay.Size = new System.Drawing.Size(107, 29);
            this.taxtopay.TabIndex = 6;
            this.taxtopay.Text = "0";
            // 
            // จำนวนภาษีที่ต้องจ่าย
            // 
            this.จำนวนภาษีที่ต้องจ่าย.AutoSize = true;
            this.จำนวนภาษีที่ต้องจ่าย.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.จำนวนภาษีที่ต้องจ่าย.ForeColor = System.Drawing.Color.Red;
            this.จำนวนภาษีที่ต้องจ่าย.Location = new System.Drawing.Point(40, 239);
            this.จำนวนภาษีที่ต้องจ่าย.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.จำนวนภาษีที่ต้องจ่าย.Name = "จำนวนภาษีที่ต้องจ่าย";
            this.จำนวนภาษีที่ต้องจ่าย.Size = new System.Drawing.Size(158, 24);
            this.จำนวนภาษีที่ต้องจ่าย.TabIndex = 7;
            this.จำนวนภาษีที่ต้องจ่าย.Text = "จำนวนภาษีที่ต้องจ่าย";
            // 
            // ย้อนกลับ
            // 
            this.ย้อนกลับ.Font = new System.Drawing.Font("Quark", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ย้อนกลับ.Location = new System.Drawing.Point(44, 591);
            this.ย้อนกลับ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ย้อนกลับ.Name = "ย้อนกลับ";
            this.ย้อนกลับ.Size = new System.Drawing.Size(121, 35);
            this.ย้อนกลับ.TabIndex = 239;
            this.ย้อนกลับ.Text = "<-- ย้อนกลับ";
            this.ย้อนกลับ.UseVisualStyleBackColor = true;
            this.ย้อนกลับ.Click += new System.EventHandler(this.ย้อนกลับ_Click);
            // 
            // re
            // 
            this.re.Font = new System.Drawing.Font("Quark", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.re.Location = new System.Drawing.Point(1118, 592);
            this.re.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.re.Name = "re";
            this.re.Size = new System.Drawing.Size(107, 35);
            this.re.TabIndex = 238;
            this.re.Text = "รีเซ็ตค่า";
            this.re.UseVisualStyleBackColor = true;
            this.re.Click += new System.EventHandler(this.re_Click);
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.BackColor = System.Drawing.Color.Transparent;
            this.label102.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(486, 505);
            this.label102.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(246, 33);
            this.label102.TabIndex = 237;
            this.label102.Text = "รวมค่าลดหย่อนประกันเงินออม";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // รวมค่าประกันเงินออม
            // 
            this.รวมค่าประกันเงินออม.BackColor = System.Drawing.Color.White;
            this.รวมค่าประกันเงินออม.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.รวมค่าประกันเงินออม.ForeColor = System.Drawing.Color.Black;
            this.รวมค่าประกันเงินออม.Location = new System.Drawing.Point(753, 505);
            this.รวมค่าประกันเงินออม.Name = "รวมค่าประกันเงินออม";
            this.รวมค่าประกันเงินออม.ReadOnly = true;
            this.รวมค่าประกันเงินออม.Size = new System.Drawing.Size(129, 39);
            this.รวมค่าประกันเงินออม.TabIndex = 236;
            this.รวมค่าประกันเงินออม.Text = "0";
            this.รวมค่าประกันเงินออม.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ประกันสังคม
            // 
            this.ประกันสังคม.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ประกันสังคม.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ประกันสังคม.Location = new System.Drawing.Point(286, 50);
            this.ประกันสังคม.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ประกันสังคม.Maximum = new decimal(new int[] {
            9000,
            0,
            0,
            0});
            this.ประกันสังคม.Name = "ประกันสังคม";
            this.ประกันสังคม.Size = new System.Drawing.Size(111, 39);
            this.ประกันสังคม.TabIndex = 187;
            this.ประกันสังคม.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ประกันสังคม.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.Transparent;
            this.label59.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.Red;
            this.label59.Location = new System.Drawing.Point(901, 436);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(18, 23);
            this.label59.TabIndex = 229;
            this.label59.Text = "0";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.Transparent;
            this.label60.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label60.Location = new System.Drawing.Point(749, 436);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(241, 46);
            this.label60.TabIndex = 228;
            this.label60.Text = "ไม่เกิน 15% ของเงินได้ จำนวน               บาท\r\nและไม่เกิน 500,000 บาท";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rmf
            // 
            this.rmf.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rmf.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rmf.Location = new System.Drawing.Point(753, 396);
            this.rmf.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rmf.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.rmf.Name = "rmf";
            this.rmf.Size = new System.Drawing.Size(120, 39);
            this.rmf.TabIndex = 227;
            this.rmf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.rmf.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.Transparent;
            this.label57.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.Red;
            this.label57.Location = new System.Drawing.Point(908, 318);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(18, 23);
            this.label57.TabIndex = 226;
            this.label57.Text = "0";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.Transparent;
            this.label58.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label58.Location = new System.Drawing.Point(753, 318);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(241, 46);
            this.label58.TabIndex = 225;
            this.label58.Text = "ไม่เกิน 15% ของเงินได้ จำนวน               บาท\r\nและไม่เกิน 500,000 บาท";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ltf
            // 
            this.ltf.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ltf.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltf.Location = new System.Drawing.Point(753, 279);
            this.ltf.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ltf.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.ltf.Name = "ltf";
            this.ltf.Size = new System.Drawing.Size(120, 39);
            this.ltf.TabIndex = 224;
            this.ltf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ltf.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Transparent;
            this.label50.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.Red;
            this.label50.Location = new System.Drawing.Point(902, 227);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(18, 23);
            this.label50.TabIndex = 217;
            this.label50.Text = "0";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(512, 400);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(179, 33);
            this.label43.TabIndex = 206;
            this.label43.Text = "จำนวนที่จะลงทุน RMF";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Transparent;
            this.label49.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Red;
            this.label49.Location = new System.Drawing.Point(902, 94);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(18, 23);
            this.label49.TabIndex = 216;
            this.label49.Text = "0";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.Transparent;
            this.label48.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.Red;
            this.label48.Location = new System.Drawing.Point(438, 552);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(18, 23);
            this.label48.TabIndex = 215;
            this.label48.Text = "0";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(520, 279);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(172, 33);
            this.label13.TabIndex = 205;
            this.label13.Text = "จำนวนที่จะลงทุน LTF";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Transparent;
            this.label47.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label47.Location = new System.Drawing.Point(749, 227);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(241, 46);
            this.label47.TabIndex = 214;
            this.label47.Text = "ไม่เกิน 15% ของเงินได้ จำนวน               บาท\r\nและไม่เกิน 200,000 บาท";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label46.Location = new System.Drawing.Point(299, 461);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(109, 23);
            this.label46.TabIndex = 213;
            this.label46.Text = "ไม่เกิน 13,200 บาท";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label45.Location = new System.Drawing.Point(749, 95);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(241, 46);
            this.label45.TabIndex = 212;
            this.label45.Text = "ไม่เกิน 15% ของเงินได้ จำนวน               บาท\r\nและไม่เกิน 500,000 บาท ";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label44.Location = new System.Drawing.Point(280, 552);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(251, 46);
            this.label44.TabIndex = 211;
            this.label44.Text = "ไม่เกิน 15% ของรายได้ จำนวน                 บาท\r\nและไม่เกิน 500,000 บาท";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // บำนาญ
            // 
            this.บำนาญ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.บำนาญ.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.บำนาญ.Location = new System.Drawing.Point(753, 188);
            this.บำนาญ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.บำนาญ.Maximum = new decimal(new int[] {
            200000,
            0,
            0,
            0});
            this.บำนาญ.Name = "บำนาญ";
            this.บำนาญ.Size = new System.Drawing.Size(120, 39);
            this.บำนาญ.TabIndex = 210;
            this.บำนาญ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.บำนาญ.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // กบข
            // 
            this.กบข.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.กบข.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.กบข.Location = new System.Drawing.Point(753, 56);
            this.กบข.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.กบข.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.กบข.Name = "กบข";
            this.กบข.Size = new System.Drawing.Size(120, 39);
            this.กบข.TabIndex = 209;
            this.กบข.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.กบข.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // ทุนสำรอง
            // 
            this.ทุนสำรอง.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ทุนสำรอง.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ทุนสำรอง.Location = new System.Drawing.Point(284, 504);
            this.ทุนสำรอง.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ทุนสำรอง.Maximum = new decimal(new int[] {
            490000,
            0,
            0,
            0});
            this.ทุนสำรอง.Name = "ทุนสำรอง";
            this.ทุนสำรอง.Size = new System.Drawing.Size(112, 39);
            this.ทุนสำรอง.TabIndex = 208;
            this.ทุนสำรอง.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ทุนสำรอง.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // กอช
            // 
            this.กอช.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.กอช.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.กอช.Location = new System.Drawing.Point(285, 421);
            this.กอช.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.กอช.Maximum = new decimal(new int[] {
            13200,
            0,
            0,
            0});
            this.กอช.Name = "กอช";
            this.กอช.Size = new System.Drawing.Size(112, 39);
            this.กอช.TabIndex = 207;
            this.กอช.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.กอช.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Transparent;
            this.label51.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(499, 188);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(216, 33);
            this.label51.TabIndex = 204;
            this.label51.Text = "เบี้ยประกันชีวิตแบบบำนาญ";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Transparent;
            this.label52.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(52, 425);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(127, 33);
            this.label52.TabIndex = 203;
            this.label52.Text = "เงินสะสม กอช.";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.Transparent;
            this.label53.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(476, 56);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(241, 66);
            this.label53.TabIndex = 202;
            this.label53.Text = "เงินสะสมกองทุน กบข.\r\nและกองทุนสงเคราะห์ครูเอกชน";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.Transparent;
            this.label54.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(34, 517);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(209, 33);
            this.label54.TabIndex = 201;
            this.label54.Text = "เงินกองทุนสำรองเลี้ยงชีพ";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.Transparent;
            this.label55.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label55.Location = new System.Drawing.Point(298, 388);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(110, 23);
            this.label55.TabIndex = 200;
            this.label55.Text = "ไม่เกิน 10,000 บาท";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ประกันสมรส
            // 
            this.ประกันสมรส.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ประกันสมรส.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ประกันสมรส.Location = new System.Drawing.Point(284, 349);
            this.ประกันสมรส.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ประกันสมรส.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ประกันสมรส.Name = "ประกันสมรส";
            this.ประกันสมรส.Size = new System.Drawing.Size(112, 39);
            this.ประกันสมรส.TabIndex = 199;
            this.ประกันสมรส.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ประกันสมรส.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.Transparent;
            this.label56.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(53, 355);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(154, 33);
            this.label56.TabIndex = 198;
            this.label56.Text = "ประกันชีวิตคู่สมรส";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.Transparent;
            this.label61.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label61.Location = new System.Drawing.Point(298, 318);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(109, 23);
            this.label61.TabIndex = 197;
            this.label61.Text = "ไม่เกิน 15,000 บาท";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // เบี้ยสุขภาพ_บด
            // 
            this.เบี้ยสุขภาพ_บด.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.เบี้ยสุขภาพ_บด.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เบี้ยสุขภาพ_บด.Location = new System.Drawing.Point(286, 278);
            this.เบี้ยสุขภาพ_บด.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เบี้ยสุขภาพ_บด.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.เบี้ยสุขภาพ_บด.Name = "เบี้ยสุขภาพ_บด";
            this.เบี้ยสุขภาพ_บด.Size = new System.Drawing.Size(112, 39);
            this.เบี้ยสุขภาพ_บด.TabIndex = 196;
            this.เบี้ยสุขภาพ_บด.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.เบี้ยสุขภาพ_บด.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.Transparent;
            this.label62.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(50, 262);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(150, 66);
            this.label62.TabIndex = 195;
            this.label62.Text = "เบี้ยประกันสุขภาพ\r\n(บิดา - มารดา)";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.Transparent;
            this.label63.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label63.Location = new System.Drawing.Point(300, 238);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(109, 23);
            this.label63.TabIndex = 194;
            this.label63.Text = "ไม่เกิน 15,000 บาท";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.Transparent;
            this.label64.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label64.Location = new System.Drawing.Point(291, 161);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(118, 23);
            this.label64.TabIndex = 193;
            this.label64.Text = "ไม่เกิน 100,000 บาท";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.Transparent;
            this.label65.Font = new System.Drawing.Font("RSU", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label65.Location = new System.Drawing.Point(303, 90);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(105, 23);
            this.label65.TabIndex = 192;
            this.label65.Text = "ไม่เกิน 9,000 บาท";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // เบี้ยสุขภาพ
            // 
            this.เบี้ยสุขภาพ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.เบี้ยสุขภาพ.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เบี้ยสุขภาพ.Location = new System.Drawing.Point(285, 198);
            this.เบี้ยสุขภาพ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เบี้ยสุขภาพ.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.เบี้ยสุขภาพ.Name = "เบี้ยสุขภาพ";
            this.เบี้ยสุขภาพ.Size = new System.Drawing.Size(111, 39);
            this.เบี้ยสุขภาพ.TabIndex = 191;
            this.เบี้ยสุขภาพ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.เบี้ยสุขภาพ.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.Transparent;
            this.label66.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(50, 198);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(150, 33);
            this.label66.TabIndex = 190;
            this.label66.Text = "เบี้ยประกันสุขภาพ";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // เบี้ยชีวิต
            // 
            this.เบี้ยชีวิต.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.เบี้ยชีวิต.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เบี้ยชีวิต.Location = new System.Drawing.Point(285, 121);
            this.เบี้ยชีวิต.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เบี้ยชีวิต.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.เบี้ยชีวิต.Name = "เบี้ยชีวิต";
            this.เบี้ยชีวิต.Size = new System.Drawing.Size(111, 39);
            this.เบี้ยชีวิต.TabIndex = 189;
            this.เบี้ยชีวิต.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.เบี้ยชีวิต.ValueChanged += new System.EventHandler(this.ประกันสังคม_ValueChanged);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.Transparent;
            this.label67.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(52, 122);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(124, 33);
            this.label67.TabIndex = 188;
            this.label67.Text = "เบี้ยประกันชีวิต";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.Transparent;
            this.label68.Font = new System.Drawing.Font("RSU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(53, 56);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(112, 33);
            this.label68.TabIndex = 186;
            this.label68.Text = "ประกันสังคม";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ถัดไป
            // 
            this.ถัดไป.Font = new System.Drawing.Font("Quark", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.ถัดไป.Location = new System.Drawing.Point(1137, 607);
            this.ถัดไป.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ถัดไป.Name = "ถัดไป";
            this.ถัดไป.Size = new System.Drawing.Size(90, 36);
            this.ถัดไป.TabIndex = 29;
            this.ถัดไป.Text = "ถัดไป -->";
            this.ถัดไป.UseVisualStyleBackColor = true;
            this.ถัดไป.Click += new System.EventHandler(this.ถัดไป_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.รวมเงินบริจาค);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.เงินบริจาคอื่นๆ);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.เงินบริจาคทั้วไป);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(658, 411);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(606, 169);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ค่าลดหย่อนการบริจาค";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(374, 144);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(14, 18);
            this.label27.TabIndex = 40;
            this.label27.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(255, 124);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(217, 36);
            this.label26.TabIndex = 39;
            this.label26.Text = "ไม่เกิน 10% ของเงินคงเหลือหลังจากหักค่าใช้จ่ายและ\r\nค่าลดหย่อนอื่นๆ   จำนวน       " +
    "             บาท";
            // 
            // รวมเงินบริจาค
            // 
            this.รวมเงินบริจาค.BackColor = System.Drawing.Color.White;
            this.รวมเงินบริจาค.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.รวมเงินบริจาค.Location = new System.Drawing.Point(257, 89);
            this.รวมเงินบริจาค.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.รวมเงินบริจาค.Name = "รวมเงินบริจาค";
            this.รวมเงินบริจาค.Size = new System.Drawing.Size(91, 31);
            this.รวมเงินบริจาค.TabIndex = 33;
            this.รวมเงินบริจาค.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(158, 92);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 24);
            this.label25.TabIndex = 38;
            this.label25.Text = "รวมเงินบริจาค";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(122, 57);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(117, 18);
            this.label24.TabIndex = 37;
            this.label24.Text = "ลดหย่อนตามเงินที่จ่ายจริง";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(406, 57);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(141, 18);
            this.label23.TabIndex = 36;
            this.label23.Text = "ลดหย่อน 2 เท่าของเงินที่จ่ายจริง";
            // 
            // เงินบริจาคอื่นๆ
            // 
            this.เงินบริจาคอื่นๆ.BackColor = System.Drawing.Color.White;
            this.เงินบริจาคอื่นๆ.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เงินบริจาคอื่นๆ.Location = new System.Drawing.Point(409, 25);
            this.เงินบริจาคอื่นๆ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เงินบริจาคอื่นๆ.Maximum = new decimal(new int[] {
            60000,
            0,
            0,
            0});
            this.เงินบริจาคอื่นๆ.Name = "เงินบริจาคอื่นๆ";
            this.เงินบริจาคอื่นๆ.Size = new System.Drawing.Size(90, 31);
            this.เงินบริจาคอื่นๆ.TabIndex = 35;
            this.เงินบริจาคอื่นๆ.ValueChanged += new System.EventHandler(this.เงินบริจาคทั้วไป_ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(252, 30);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(147, 24);
            this.label22.TabIndex = 34;
            this.label22.Text = "เงินบริจาคสนับสนุนอื่นๆ";
            // 
            // เงินบริจาคทั้วไป
            // 
            this.เงินบริจาคทั้วไป.BackColor = System.Drawing.Color.White;
            this.เงินบริจาคทั้วไป.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เงินบริจาคทั้วไป.Location = new System.Drawing.Point(125, 25);
            this.เงินบริจาคทั้วไป.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เงินบริจาคทั้วไป.Maximum = new decimal(new int[] {
            60000,
            0,
            0,
            0});
            this.เงินบริจาคทั้วไป.Name = "เงินบริจาคทั้วไป";
            this.เงินบริจาคทั้วไป.Size = new System.Drawing.Size(90, 31);
            this.เงินบริจาคทั้วไป.TabIndex = 33;
            this.เงินบริจาคทั้วไป.ValueChanged += new System.EventHandler(this.เงินบริจาคทั้วไป_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 30);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 24);
            this.label3.TabIndex = 17;
            this.label3.Text = "เงินบริจาคทั้วไป";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.label41);
            this.groupBox3.Controls.Add(this.label40);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.เที่ยวเมืองรอง);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Controls.Add(this.เที่ยวเมืองหลัก);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.โอทอป);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Controls.Add(this.หนังสือ);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.ซื้อการศึกษา);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.ช่วยชาติ);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Location = new System.Drawing.Point(658, 89);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(596, 315);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ค่าลดหย่อนตามมาตรการกระตุ้นเศรษฐกิจของรัฐ";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(334, 233);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(91, 31);
            this.textBox2.TabIndex = 36;
            this.textBox2.Text = "0";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(331, 267);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(159, 36);
            this.label41.TabIndex = 54;
            this.label41.Text = "การท่องเที่ยวในเมืองหลักและเมืองรอง\r\nลดหย่อนรวมกันได้ไม่เกิน 20,000";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(139, 236);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(187, 24);
            this.label40.TabIndex = 53;
            this.label40.Text = "รวมค่าลดหย่อนกระตุ้นเศรษฐกิจ";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(500, 204);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(68, 18);
            this.label39.TabIndex = 52;
            this.label39.Text = "ไม่เกิน 20,000";
            // 
            // เที่ยวเมืองรอง
            // 
            this.เที่ยวเมืองรอง.BackColor = System.Drawing.Color.White;
            this.เที่ยวเมืองรอง.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เที่ยวเมืองรอง.Location = new System.Drawing.Point(478, 171);
            this.เที่ยวเมืองรอง.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เที่ยวเมืองรอง.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.เที่ยวเมืองรอง.Name = "เที่ยวเมืองรอง";
            this.เที่ยวเมืองรอง.Size = new System.Drawing.Size(90, 31);
            this.เที่ยวเมืองรอง.TabIndex = 51;
            this.เที่ยวเมืองรอง.ValueChanged += new System.EventHandler(this.ช่วยชาติ_ValueChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(297, 175);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(141, 24);
            this.label38.TabIndex = 50;
            this.label38.Text = "ท่องเที่ยวไทยในเมืองรอง";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(200, 200);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(66, 18);
            this.label37.TabIndex = 49;
            this.label37.Text = "ไม่เกิน 15,000";
            // 
            // เที่ยวเมืองหลัก
            // 
            this.เที่ยวเมืองหลัก.BackColor = System.Drawing.Color.White;
            this.เที่ยวเมืองหลัก.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.เที่ยวเมืองหลัก.Location = new System.Drawing.Point(172, 168);
            this.เที่ยวเมืองหลัก.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.เที่ยวเมืองหลัก.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.เที่ยวเมืองหลัก.Name = "เที่ยวเมืองหลัก";
            this.เที่ยวเมืองหลัก.Size = new System.Drawing.Size(90, 31);
            this.เที่ยวเมืองหลัก.TabIndex = 48;
            this.เที่ยวเมืองหลัก.ValueChanged += new System.EventHandler(this.ช่วยชาติ_ValueChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(16, 173);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(143, 24);
            this.label36.TabIndex = 47;
            this.label36.Text = "ท่องเที่ยวไทยในเมืองหลัก";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(506, 144);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(66, 18);
            this.label35.TabIndex = 46;
            this.label35.Text = "ไม่เกิน 15,000";
            // 
            // โอทอป
            // 
            this.โอทอป.BackColor = System.Drawing.Color.White;
            this.โอทอป.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.โอทอป.Location = new System.Drawing.Point(478, 110);
            this.โอทอป.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.โอทอป.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.โอทอป.Name = "โอทอป";
            this.โอทอป.Size = new System.Drawing.Size(90, 31);
            this.โอทอป.TabIndex = 45;
            this.โอทอป.ValueChanged += new System.EventHandler(this.ช่วยชาติ_ValueChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(330, 110);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(96, 24);
            this.label34.TabIndex = 44;
            this.label34.Text = "ซื้อสินค้าโอทอป";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(200, 138);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(66, 18);
            this.label33.TabIndex = 43;
            this.label33.Text = "ไม่เกิน 15,000";
            // 
            // หนังสือ
            // 
            this.หนังสือ.BackColor = System.Drawing.Color.White;
            this.หนังสือ.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.หนังสือ.Location = new System.Drawing.Point(172, 104);
            this.หนังสือ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.หนังสือ.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.หนังสือ.Name = "หนังสือ";
            this.หนังสือ.Size = new System.Drawing.Size(90, 31);
            this.หนังสือ.TabIndex = 42;
            this.หนังสือ.ValueChanged += new System.EventHandler(this.ช่วยชาติ_ValueChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(43, 106);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(66, 24);
            this.label32.TabIndex = 41;
            this.label32.Text = "ซื้อหนังสือ";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(506, 64);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(66, 18);
            this.label31.TabIndex = 40;
            this.label31.Text = "ไม่เกิน 15,000";
            // 
            // ซื้อการศึกษา
            // 
            this.ซื้อการศึกษา.BackColor = System.Drawing.Color.White;
            this.ซื้อการศึกษา.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ซื้อการศึกษา.Location = new System.Drawing.Point(478, 32);
            this.ซื้อการศึกษา.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ซื้อการศึกษา.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.ซื้อการศึกษา.Name = "ซื้อการศึกษา";
            this.ซื้อการศึกษา.Size = new System.Drawing.Size(90, 31);
            this.ซื้อการศึกษา.TabIndex = 39;
            this.ซื้อการศึกษา.ValueChanged += new System.EventHandler(this.ช่วยชาติ_ValueChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(297, 40);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(159, 24);
            this.label30.TabIndex = 38;
            this.label30.Text = "ซื้อสินค้าการศึกษาและกีฬา";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("RSU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(200, 71);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(66, 18);
            this.label29.TabIndex = 37;
            this.label29.Text = "ไม่เกิน 15,000";
            // 
            // ช่วยชาติ
            // 
            this.ช่วยชาติ.BackColor = System.Drawing.Color.White;
            this.ช่วยชาติ.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ช่วยชาติ.Location = new System.Drawing.Point(172, 38);
            this.ช่วยชาติ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ช่วยชาติ.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.ช่วยชาติ.Name = "ช่วยชาติ";
            this.ช่วยชาติ.Size = new System.Drawing.Size(90, 31);
            this.ช่วยชาติ.TabIndex = 34;
            this.ช่วยชาติ.ValueChanged += new System.EventHandler(this.ช่วยชาติ_ValueChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("RSU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(43, 45);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(79, 24);
            this.label28.TabIndex = 18;
            this.label28.Text = "ช้อปช่วยชาติ";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Font = new System.Drawing.Font("RSU", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label42.Location = new System.Drawing.Point(522, 22);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(243, 47);
            this.label42.TabIndex = 32;
            this.label42.Text = "โปรแกรมคำนวนภาษี";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Font = new System.Drawing.Font("RSU", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.numericUpDown2.Location = new System.Drawing.Point(280, 108);
            this.numericUpDown2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            1569325055,
            23283064,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(116, 47);
            this.numericUpDown2.TabIndex = 36;
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightYellow;
            this.ClientSize = new System.Drawing.Size(1275, 650);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ถัดไป);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimumSize = new System.Drawing.Size(1154, 671);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.ฝากครรภ์)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.พิการ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.บิดามารดาคู่สมรส)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.บิดามารดาเรา)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.บุตร61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.บุตร60)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.บ้านหลังแรก62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.บ้านหลังแรก)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ดอกเบี้ยบ้าน)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ประกันสังคม)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rmf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ltf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.บำนาญ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.กบข)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ทุนสำรอง)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.กอช)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ประกันสมรส)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยสุขภาพ_บด)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยสุขภาพ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.เบี้ยชีวิต)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.เงินบริจาคอื่นๆ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.เงินบริจาคทั้วไป)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.เที่ยวเมืองรอง)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.เที่ยวเมืองหลัก)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.โอทอป)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.หนังสือ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ซื้อการศึกษา)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ช่วยชาติ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown ฝากครรภ์;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown บิดามารดาคู่สมรส;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown บิดามารดาเรา;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown บุตร61;
        private System.Windows.Forms.NumericUpDown บุตร60;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox คู่สมรส;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox รวมค่าอสังหาริมทรพย์;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown บ้านหลังแรก62;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown บ้านหลังแรก;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown ดอกเบี้ยบ้าน;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button ถัดไป;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox รวมเงินบริจาค;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown เงินบริจาคอื่นๆ;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown เงินบริจาคทั้วไป;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.NumericUpDown เที่ยวเมืองรอง;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown เที่ยวเมืองหลัก;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown โอทอป;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown หนังสือ;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown ซื้อการศึกษา;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown ช่วยชาติ;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.NumericUpDown พิการ;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox ลดย่อน;
        private System.Windows.Forms.Label รายได้สุทธิ;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button คำนวน;
        private System.Windows.Forms.TextBox salary12;
        private System.Windows.Forms.TextBox taxtopay;
        private System.Windows.Forms.Label จำนวนภาษีที่ต้องจ่าย;
        private System.Windows.Forms.Button ย้อนกลับ;
        private System.Windows.Forms.Button re;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.TextBox รวมค่าประกันเงินออม;
        private System.Windows.Forms.NumericUpDown ประกันสังคม;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.NumericUpDown rmf;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.NumericUpDown ltf;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown บำนาญ;
        private System.Windows.Forms.NumericUpDown กบข;
        private System.Windows.Forms.NumericUpDown ทุนสำรอง;
        private System.Windows.Forms.NumericUpDown กอช;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.NumericUpDown ประกันสมรส;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.NumericUpDown เบี้ยสุขภาพ_บด;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.NumericUpDown เบี้ยสุขภาพ;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.NumericUpDown เบี้ยชีวิต;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
    }
}

